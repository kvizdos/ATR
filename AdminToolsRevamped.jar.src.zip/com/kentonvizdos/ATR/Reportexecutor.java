/*    */ package com.kentonvizdos.ATR;
/*    */ 
/*    */ import net.md_5.bungee.api.ChatColor;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.configuration.file.FileConfiguration;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class Reportexecutor implements CommandExecutor
/*    */ {
/*    */   private final main PLUGIN;
/*    */   
/*    */   public Reportexecutor(main plugin)
/*    */   {
/* 17 */     this.PLUGIN = plugin;
/*    */   }
/*    */   
/*    */ 
/*    */ 
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args)
/*    */   {
/* 24 */     Player player = (Player)sender;
/* 25 */     if ((cmd.getName().equalsIgnoreCase("report")) && (player.hasPermission("at.report"))) {
/* 26 */       String mess = "";
/*    */       
/* 28 */       for (int i = 1; i < args.length; i++) {
/* 29 */         String arg = args[i] + " ";
/* 30 */         mess = mess + arg;
/*    */       }
/*    */       
/* 33 */       Player target = Bukkit.getServer().getPlayer(args[0]);
/*    */       
/* 35 */       if (args.length == 1) {
/* 36 */         player.sendMessage(this.PLUGIN.error + "Do /report <player> <reason>!");
/*    */       }
/* 38 */       else if (args.length == 0) {
/* 39 */         player.sendMessage(this.PLUGIN.error + "Please Specify A Player!");
/*    */       } else {
/* 41 */         player.sendMessage(this.PLUGIN.prefix + "Successfully Reported " + ChatColor.RED + target.getName() + ChatColor.AQUA + " for the reason: " + ChatColor.RED + mess);
/* 42 */         this.PLUGIN.getConfig().addDefault("Reported." + target.getName() + ".Report", mess);
/* 43 */         this.PLUGIN.getConfig().addDefault("Reported." + target.getName() + ".Reporter", player.getName());
/* 44 */         this.PLUGIN.saveConfig();
/*    */         
/* 46 */         Bukkit.broadcast(this.PLUGIN.prefix + target.getName() + " was reported by " + player.getName() + " for the reason: " + mess, "at.recieve");
/*    */       }
/*    */     }
/*    */     
/*    */ 
/* 51 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kento\Desktop\server\plugins\AdminToolsRevamped.jar!\com\kentonvizdos\ATR\Reportexecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */