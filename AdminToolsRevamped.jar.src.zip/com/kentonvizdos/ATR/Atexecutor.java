/*     */ package com.kentonvizdos.ATR;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.UUID;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.command.CommandSender;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ 
/*     */ public class Atexecutor implements org.bukkit.command.CommandExecutor
/*     */ {
/*  17 */   public boolean voteInprogress = false;
/*     */   private final main PLUGIN;
/*     */   
/*     */   public Atexecutor(main plugin)
/*     */   {
/*  22 */     this.PLUGIN = plugin;
/*     */   }
/*     */   
/*  25 */   String error = ChatColor.DARK_RED + "[AdminTools] Error in syntax! ";
/*  26 */   String prefix = ChatColor.DARK_AQUA + "[" + ChatColor.AQUA + "AdminTools" + ChatColor.DARK_AQUA + "] " + 
/*  27 */     ChatColor.AQUA;
/*     */   
/*     */   public boolean onCommand(CommandSender sender, org.bukkit.command.Command cmd, String commandLabel, String[] args)
/*     */   {
/*  31 */     Player player = (Player)sender;
/*     */     
/*  33 */     if (cmd.getName().equalsIgnoreCase("at")) {
/*  34 */       if (args.length == 0) {
/*  35 */         player.sendMessage(ChatColor.AQUA + "===--------------------------------------===");
/*  36 */         player.sendMessage(ChatColor.AQUA + "===-------------" + ChatColor.DARK_AQUA + "ADMIN  TOOLS" + 
/*  37 */           ChatColor.AQUA + "--------------===");
/*  38 */         player.sendMessage(ChatColor.AQUA + "COMMAND | DESCRIPTION | PERMISSION");
/*  39 */         player.sendMessage(ChatColor.DARK_AQUA + "1) " + ChatColor.AQUA + "/at bc <message>" + 
/*  40 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "Send A Message To Everyone!" + 
/*  41 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "at.bc");
/*  42 */         player.sendMessage(ChatColor.DARK_AQUA + "2) " + ChatColor.AQUA + "/at gm <c/s/a/sp>" + 
/*  43 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "Change Your Gamemode!" + ChatColor.DARK_AQUA + 
/*  44 */           " | " + ChatColor.AQUA + "at.gm");
/*  45 */         player.sendMessage(ChatColor.DARK_AQUA + "3) " + ChatColor.AQUA + "/at ban <player> <reason>" + 
/*  46 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "Ban A Player!" + ChatColor.DARK_AQUA + " | " + 
/*  47 */           ChatColor.AQUA + "at.ban");
/*  48 */         player.sendMessage(ChatColor.DARK_AQUA + "4) " + ChatColor.AQUA + "/at config" + 
/*  49 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "Show Configurations" + ChatColor.DARK_AQUA + 
/*  50 */           " | " + ChatColor.AQUA + "at.config");
/*  51 */         player.sendMessage(ChatColor.DARK_AQUA + "5) " + ChatColor.AQUA + "/at freeze <player>" + 
/*  52 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "Freeze A player (toggles)" + 
/*  53 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "at.freeze");
/*  54 */         player.sendMessage(ChatColor.DARK_AQUA + "6) " + ChatColor.AQUA + "/at spec <player>" + 
/*  55 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "Spectate a Player!" + ChatColor.DARK_AQUA + 
/*  56 */           " | " + ChatColor.AQUA + "at.spec");
/*  57 */         player.sendMessage(ChatColor.DARK_AQUA + "7) " + ChatColor.AQUA + "/at heal <player/all>" + 
/*  58 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "Heal !" + ChatColor.DARK_AQUA + " | " + 
/*  59 */           ChatColor.AQUA + "at.heal");
/*  60 */         player.sendMessage(ChatColor.DARK_AQUA + "8) " + ChatColor.AQUA + "/at warn <player>" + 
/*  61 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "Warn A player !" + ChatColor.DARK_AQUA + " | " + 
/*  62 */           ChatColor.AQUA + "at.warn");
/*  63 */         player.sendMessage(ChatColor.DARK_AQUA + "9) " + ChatColor.AQUA + "/at research <player>" + 
/*  64 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "Get More info About a player" + 
/*  65 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "at.research");
/*  66 */         player.sendMessage(ChatColor.DARK_AQUA + "10) " + ChatColor.AQUA + "/911 <reason>" + 
/*  67 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "Have Players Contact Staff For An Emergancy" + 
/*  68 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "at.emergancy");
/*  69 */         player.sendMessage(ChatColor.DARK_AQUA + "11) " + ChatColor.AQUA + "/report <player> <reason>" + 
/*  70 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "Report a player!" + ChatColor.DARK_AQUA + 
/*  71 */           " | " + ChatColor.AQUA + "at.report");
/*  72 */         player.sendMessage(ChatColor.DARK_AQUA + "12) " + ChatColor.AQUA + "/at invcheck <player>" + 
/*  73 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "Look at a players inventory" + 
/*  74 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "at.invcheck");
/*  75 */         player.sendMessage(ChatColor.DARK_AQUA + "13) " + ChatColor.AQUA + "/at blacklist <add/remove> <word>" + 
/*  76 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "Add/Remove a word from blacklist!" + 
/*  77 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "at.blacklist");
/*  78 */         player.sendMessage(ChatColor.DARK_AQUA + "14) " + ChatColor.AQUA + "/at blacklisted" + 
/*  79 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "Displays All Blacklisted Words" + 
/*  80 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "at.blacklisted");
/*  81 */         player.sendMessage(ChatColor.DARK_AQUA + "14) " + ChatColor.AQUA + "/at contributors" + 
/*  82 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "Displays All Contributors That Have Helped!" + 
/*  83 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "at.contributors");
/*  84 */         player.sendMessage(ChatColor.DARK_AQUA + "15) " + ChatColor.AQUA + "/at voteban <player> <reason> || /at voteban <yes/no>" + 
/*  85 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "Start the voteban || Vote for the voteban" + 
/*  86 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "at.voteban");
/*  87 */         player.sendMessage(ChatColor.DARK_AQUA + "16) " + ChatColor.AQUA + "/at votekick <player> <reason> || /at votekick <yes/no>" + 
/*  88 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "Start the votekick || Vote for the votekick" + 
/*  89 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "at.votekick");
/*  90 */         player.sendMessage(ChatColor.DARK_AQUA + "17) " + ChatColor.AQUA + "/at mute <player> <reason>" + 
/*  91 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "Mutes a player of your choice!" + 
/*  92 */           ChatColor.DARK_AQUA + " | " + ChatColor.AQUA + "at.mute");
/*  93 */         player.sendMessage(this.prefix + 
/*  94 */           "AdminTools Created By Kenton Vizdos \n (DOESNT WORK ATM) www.kentonvizdos.com/minecraft/plugins/AdminTools.php");
/*     */ 
/*     */ 
/*     */       }
/*  98 */       else if ((args[0].equalsIgnoreCase("bc")) && (player.hasPermission("at.bc"))) {
/*  99 */         if (args.length != 1) {
/* 100 */           String mess = "";
/*     */           
/* 102 */           for (int i = 1; i < args.length; i++) {
/* 103 */             String arg = args[i] + " ";
/* 104 */             mess = mess + arg;
/*     */           }
/*     */           
/* 107 */           Bukkit.getServer().broadcastMessage(ChatColor.DARK_RED + "[" + ChatColor.RED + "BROADCAST" + 
/* 108 */             ChatColor.DARK_RED + "] " + ChatColor.AQUA + mess);
/*     */ 
/*     */ 
/*     */         }
/*     */         else
/*     */         {
/*     */ 
/*     */ 
/* 116 */           player.sendMessage(this.error + "Do /at bc <message>");
/*     */         }
/*     */         
/*     */       }
/* 120 */       else if (args[0].equalsIgnoreCase("gm")) {
/* 121 */         if (args.length != 2) {
/* 122 */           player.sendMessage(this.error + "Do /at gm <c/s/a/sp>");
/* 123 */         } else if (args[1].equalsIgnoreCase("c")) {
/* 124 */           player.setGameMode(GameMode.CREATIVE);
/* 125 */           player.sendMessage(this.prefix + "Gamemode set to Creative!");
/* 126 */         } else if (args[1].equalsIgnoreCase("s")) {
/* 127 */           player.setGameMode(GameMode.SURVIVAL);
/* 128 */           player.sendMessage(this.prefix + "Gamemode set to Survival!");
/* 129 */         } else if (args[1].equalsIgnoreCase("a")) {
/* 130 */           player.setGameMode(GameMode.ADVENTURE);
/* 131 */           player.sendMessage(this.prefix + "Gamemode set to Adventure!");
/* 132 */         } else if (args[1].equalsIgnoreCase("sp")) {
/* 133 */           player.setGameMode(GameMode.SPECTATOR);
/* 134 */           player.sendMessage(this.prefix + "Gamemode set to Spectator/!");
/*     */         } else {
/* 136 */           player.sendMessage(this.error + "Do /at gm <c/s/a/sp>");
/*     */         }
/*     */         
/*     */       }
/* 140 */       else if ((args[0].equalsIgnoreCase("ban")) && (player.hasPermission("at.ban")))
/*     */       {
/* 142 */         if (args.length != 2) {
/* 143 */           Player target = Bukkit.getServer().getPlayer(args[1]);
/* 144 */           String mess = "";
/*     */           
/* 146 */           for (int i = 2; i < args.length; i++) {
/* 147 */             String arg = args[i] + " ";
/* 148 */             mess = mess + arg;
/*     */           }
/* 150 */           if ((target != null) && (player.hasPermission("at.unbannable")))
/*     */           {
/* 152 */             player.sendMessage(this.prefix + "Banned " + target.getName() + "!");
/* 153 */             target.kickPlayer(ChatColor.RED + "You Have Been Banned! \n Reason: " + ChatColor.DARK_RED + 
/* 154 */               "The Ban Hammer Has Spoken!" + ChatColor.RED + " \n Banned By: " + ChatColor.DARK_RED + 
/* 155 */               player.getName() + ChatColor.RED + "\n Appeal Here: \n" + ChatColor.DARK_RED + 
/* 156 */               this.PLUGIN.getConfig().getString("Settings.Ban.AppealLink"));
/*     */             
/* 158 */             this.PLUGIN.getConfig().set("Players.Banned." + target.getUniqueId() + ".Reason", 
/* 159 */               "The Ban Hammer Has Spoken!");
/* 160 */             this.PLUGIN.getConfig().set("Players.Banned." + target.getUniqueId() + ".Banner", player.getName());
/*     */             
/* 162 */             this.PLUGIN.saveConfig();
/*     */           } else {
/* 164 */             player.sendMessage(this.error + "Player Not Found");
/*     */           }
/*     */         }
/*     */         else {
/* 168 */           player.sendMessage(this.error + "Do /ban <player>");
/*     */         }
/*     */         
/*     */ 
/*     */       }
/* 173 */       else if ((args[0].equalsIgnoreCase("kick")) && (player.hasPermission("at.kick")))
/*     */       {
/* 175 */         if (args.length != 2) {
/* 176 */           Player target = Bukkit.getServer().getPlayer(args[1]);
/* 177 */           String mess = "";
/*     */           
/* 179 */           for (int i = 2; i < args.length; i++) {
/* 180 */             String arg = args[i] + " ";
/* 181 */             mess = mess + arg;
/*     */           }
/* 183 */           if ((target != null) && (player.hasPermission("at.unbannable"))) {
/* 184 */             target.kickPlayer(ChatColor.RED + "You Have Been Kicked! \n Reason: " + ChatColor.DARK_RED + 
/* 185 */               mess + ChatColor.RED + "\n Kicked By: " + ChatColor.DARK_RED + player.getName());
/*     */           } else {
/* 187 */             player.sendMessage(this.error + "Player Not Found");
/*     */           }
/*     */         }
/*     */         else
/*     */         {
/* 192 */           player.sendMessage(this.error + "Do /ban <player>");
/*     */         }
/*     */       }
/*     */       else {
/*     */         String arg;
/* 197 */         if ((args[0].equalsIgnoreCase("config")) && (player.hasPermission("at.config"))) {
/* 198 */           if (args.length == 1) {
/* 199 */             player.sendMessage(
/* 200 */               this.prefix + "Config Settings (Do /at config <setting to change> To See More info on them!");
/* 201 */             player.sendMessage(ChatColor.BLUE + "1) " + ChatColor.AQUA + "Join Message: " + ChatColor.DARK_AQUA + 
/* 202 */               this.PLUGIN.getConfig().getString("Settings.Join.Msg") + ChatColor.AQUA + " | joinmsg | " + 
/* 203 */               ChatColor.RESET + 
/* 204 */               this.PLUGIN.getConfig().getString("Settings.Join.Msg").replaceAll("PLAYER", player.getName())
/* 205 */               .replaceAll("RED", new StringBuilder().append(ChatColor.RED).toString()).replaceAll("BLUE", new StringBuilder().append(ChatColor.BLUE).toString())
/* 206 */               .replaceAll("GREEN", new StringBuilder().append(ChatColor.GREEN).toString()).replaceAll("GOLD", new StringBuilder().append(ChatColor.GOLD).toString())
/* 207 */               .replaceAll("GRAY", new StringBuilder().append(ChatColor.GRAY).toString()).replaceAll("DG", new StringBuilder().append(ChatColor.DARK_GRAY).toString())
/* 208 */               .replaceAll("AQUA", new StringBuilder().append(ChatColor.AQUA).toString()));
/* 209 */             player.sendMessage(ChatColor.BLUE + "2) " + ChatColor.AQUA + "Leave Message: " + ChatColor.DARK_AQUA + 
/* 210 */               this.PLUGIN.getConfig().getString("Settings.Leave.Msg") + ChatColor.AQUA + " | leavemsg | " + 
/* 211 */               ChatColor.RESET + 
/* 212 */               this.PLUGIN.getConfig().getString("Settings.Leave.Msg").replaceAll("PLAYER", player.getName())
/* 213 */               .replaceAll("RED", new StringBuilder().append(ChatColor.RED).toString()).replaceAll("BLUE", new StringBuilder().append(ChatColor.BLUE).toString())
/* 214 */               .replaceAll("GREEN", new StringBuilder().append(ChatColor.GREEN).toString()).replaceAll("GOLD", new StringBuilder().append(ChatColor.GOLD).toString())
/* 215 */               .replaceAll("GRAY", new StringBuilder().append(ChatColor.GRAY).toString()).replaceAll("DG", new StringBuilder().append(ChatColor.DARK_GRAY).toString())
/* 216 */               .replaceAll("AQUA", new StringBuilder().append(ChatColor.AQUA).toString()));
/* 217 */           } else if (args[1].equalsIgnoreCase("joinmsg")) {
/* 218 */             if (args.length == 2) {
/* 219 */               player.sendMessage(this.prefix + "Do /at config joinmsg <join message>!");
/* 220 */               player.sendMessage(ChatColor.AQUA + "Chat Color Codes");
/* 221 */               player.sendMessage(ChatColor.RED + "RED = Red Color");
/* 222 */               player.sendMessage(ChatColor.BLUE + "BLUE = Blue Color");
/* 223 */               player.sendMessage(ChatColor.GREEN + "GREEN = Green Color");
/* 224 */               player.sendMessage(ChatColor.GOLD + "GOLD = Gold Color");
/* 225 */               player.sendMessage(ChatColor.GRAY + "GRAY = Gray Color");
/* 226 */               player.sendMessage(ChatColor.DARK_GRAY + "DG = Dark Gray Color");
/* 227 */               player.sendMessage(ChatColor.AQUA + "AQUA = Aqua Color");
/*     */             }
/*     */             else {
/* 230 */               String mess = "";
/*     */               
/* 232 */               for (int i = 2; i < args.length; i++) {
/* 233 */                 String arg = args[i] + " ";
/* 234 */                 mess = mess + arg;
/*     */               }
/*     */               
/* 237 */               this.PLUGIN.getConfig().set("Settings.Join.Msg", mess);
/* 238 */               this.PLUGIN.saveConfig();
/* 239 */               this.PLUGIN.reloadConfig();
/* 240 */               player.sendMessage(this.prefix + "Correct?: " + 
/* 241 */                 this.PLUGIN.stripColorFromConfig(this.PLUGIN.getConfig().getString("Settings.Join.Msg")));
/*     */             }
/* 243 */           } else if (args[1].equalsIgnoreCase("leavemsg")) {
/* 244 */             if (args.length == 2) {
/* 245 */               player.sendMessage(this.prefix + "Do /at config leavemsg <join message>!");
/* 246 */               player.sendMessage(ChatColor.AQUA + "Chat Color Codes");
/* 247 */               player.sendMessage(ChatColor.RED + "RED = Red Color");
/* 248 */               player.sendMessage(ChatColor.BLUE + "BLUE = Blue Color");
/* 249 */               player.sendMessage(ChatColor.GREEN + "GREEN = Green Color");
/* 250 */               player.sendMessage(ChatColor.GOLD + "GOLD = Gold Color");
/* 251 */               player.sendMessage(ChatColor.GRAY + "GRAY = Gray Color");
/* 252 */               player.sendMessage(ChatColor.DARK_GRAY + "DG = Dark Gray Color");
/* 253 */               player.sendMessage(ChatColor.AQUA + "AQUA = Aqua Color");
/*     */             } else {
/* 255 */               String mess = "";
/*     */               
/* 257 */               for (int i = 2; i < args.length; i++) {
/* 258 */                 arg = args[i] + " ";
/* 259 */                 mess = mess + arg;
/*     */               }
/*     */               
/* 262 */               this.PLUGIN.getConfig().set("Settings.Leave.Msg", mess);
/* 263 */               this.PLUGIN.saveConfig();
/* 264 */               this.PLUGIN.reloadConfig();
/*     */               
/* 266 */               player.sendMessage(this.prefix + "Correct?: " + 
/* 267 */                 this.PLUGIN.stripColorFromConfig(this.PLUGIN.getConfig().getString("Settings.Leave.Msg")));
/*     */             }
/*     */             
/*     */           }
/*     */         }
/* 272 */         else if ((args[0].equalsIgnoreCase("freeze")) && (player.hasPermission("at.freeze")))
/*     */         {
/* 274 */           if (args.length == 0) {
/* 275 */             sender.sendMessage(this.error + ChatColor.RED + "Please specify a player!");
/* 276 */             return true;
/*     */           }
/* 278 */           Player target = Bukkit.getServer().getPlayer(args[1]);
/* 279 */           if (target == null) {
/* 280 */             sender.sendMessage(this.error + ChatColor.RED + "Could not find player " + args[0] + "!");
/* 281 */             return true;
/*     */           }
/* 283 */           if (this.PLUGIN.frozen.contains(target.getName())) {
/* 284 */             this.PLUGIN.frozen.remove(target.getName());
/* 285 */             sender.sendMessage(
/* 286 */               this.prefix + ChatColor.GREEN + "Player " + target.getName() + " has been unPLUGIN.frozen!");
/* 287 */             return true;
/*     */           }
/* 289 */           this.PLUGIN.frozen.add(target.getName());
/* 290 */           sender.sendMessage(
/* 291 */             this.prefix + ChatColor.GREEN + "Player " + target.getName() + " has been PLUGIN.frozen!");
/*     */ 
/*     */         }
/* 294 */         else if ((args[0].contains("spec")) && (player.hasPermission("at.spec"))) {
/* 295 */           if (args.length == 0) {
/* 296 */             sender.sendMessage(this.error + ChatColor.RED + "Please specify a player!");
/* 297 */             return true;
/*     */           }
/* 299 */           Player target = Bukkit.getServer().getPlayer(args[1]);
/* 300 */           if (target == null) {
/* 301 */             player.sendMessage(this.error + "Player Not Found.");
/* 302 */             return true;
/*     */           }
/* 304 */           if (!this.PLUGIN.spectating) {
/* 305 */             player.teleport(target);
/* 306 */             for (Player players : Bukkit.getOnlinePlayers()) {
/* 307 */               players.hidePlayer(player);
/* 308 */               player.sendMessage(this.prefix + "You Are Invisible To All Players And PLUGIN.spectating " + 
/* 309 */                 ChatColor.BLUE + target.getName());
/* 310 */               this.PLUGIN.spectating = true;
/*     */             }
/*     */           } else {
/* 313 */             for (Player players : Bukkit.getOnlinePlayers()) {
/* 314 */               players.showPlayer(player);
/* 315 */               player.sendMessage(
/* 316 */                 this.prefix + "You have stopped PLUGIN.spectating " + ChatColor.BLUE + target.getName());
/* 317 */               this.PLUGIN.spectating = false;
/*     */             }
/*     */             
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 324 */         else if ((args[0].equalsIgnoreCase("heal")) && (player.hasPermission("at.heal"))) {
/* 325 */           if (args.length == 1) {
/* 326 */             player.setHealth(20.0D);
/* 327 */             player.sendMessage(this.prefix + "Healed!");
/*     */           }
/*     */           else {
/* 330 */             Player target = Bukkit.getServer().getPlayer(args[1]);
/*     */             
/* 332 */             if (target != null) {
/* 333 */               target.setHealth(20.0D);
/* 334 */               target.sendMessage(this.prefix + "Healed By " + player.getName() + "!");
/* 335 */               player.sendMessage(this.prefix + "Healed " + target.getName() + "!");
/*     */             }
/*     */             
/*     */ 
/* 339 */             if (args[1].equalsIgnoreCase("all")) {
/* 340 */               for (Player s : Bukkit.getOnlinePlayers()) {
/* 341 */                 s.setHealth(20.0D);
/* 342 */                 s.sendMessage(this.prefix + player.getName() + " has healed you!");
/*     */               }
/*     */               
/*     */             }
/*     */             
/*     */           }
/*     */         }
/* 349 */         else if ((args[0].equalsIgnoreCase("warn")) && (player.hasPermission("at.warn"))) {
/* 350 */           Player target = Bukkit.getPlayer(args[1]);
/*     */           
/* 352 */           if (target != null) {
/* 353 */             if (args.length == 2) {
/* 354 */               player.sendMessage(this.prefix + ChatColor.GOLD + target.getName() + ChatColor.AQUA + " has " + 
/* 355 */                 this.PLUGIN.getConfig().getString(new StringBuilder("Players.Warns.").append(target.getName()).toString()) + "/3 warn(s)!");
/* 356 */               return true;
/*     */             }
/* 358 */             if (args[2].equalsIgnoreCase("add")) {
/* 359 */               String mess = "";
/*     */               
/* 361 */               for (int i = 2; i < args.length; i++) {
/* 362 */                 String arg = args[i] + " ";
/* 363 */                 mess = mess + arg;
/*     */               }
/*     */               
/* 366 */               player.sendMessage(this.prefix + "Added 1 Warn to " + target.getName() + "!");
/* 367 */               this.PLUGIN.getConfig().set("Players.Warns." + target.getName(), 
/* 368 */                 Integer.valueOf(this.PLUGIN.getConfig().getInt("Players.Warns." + target.getName(), 0) + 1));
/* 369 */               this.PLUGIN.saveConfig();
/* 370 */               target.sendMessage(this.prefix + "You Have Been Warned! " + 
/* 371 */                 this.PLUGIN.getConfig().getString(new StringBuilder("Players.Warns.").append(target.getName()).toString()) + "/3 Warns!");
/*     */             }
/*     */           } else {
/* 374 */             player.sendMessage(this.error + "Please specify a valid, online player!");
/*     */           }
/*     */           
/*     */         }
/* 378 */         else if ((args[0].equalsIgnoreCase("research")) && (player.hasPermission("at.research"))) {
/* 379 */           Player target = Bukkit.getPlayer(args[1]);
/*     */           
/* 381 */           if (target != null) {
/* 382 */             player.sendMessage(ChatColor.AQUA + "More Info About " + ChatColor.GREEN + target.getName());
/* 383 */             player.sendMessage(ChatColor.BLUE + "Name: " + ChatColor.GREEN + target.getName());
/* 384 */             player.sendMessage(ChatColor.BLUE + "UUID: " + ChatColor.GREEN + target.getUniqueId());
/* 385 */             player.sendMessage(ChatColor.BLUE + "IP: " + ChatColor.GREEN + target.getAddress());
/*     */           } else {
/* 387 */             player.sendMessage(this.error + "Invalid Player!");
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 392 */         else if ((args[0].equalsIgnoreCase("invcheck")) && (player.hasPermission("at.invcheck"))) {
/* 393 */           Player target = Bukkit.getServer().getPlayer(args[1]);
/*     */           
/* 395 */           org.bukkit.inventory.Inventory targetInv = target.getInventory();
/*     */           
/* 397 */           if (target != null) {
/* 398 */             player.openInventory(targetInv);
/*     */             
/* 400 */             player.sendMessage(this.prefix + "Now Looking at " + target.getName() + "'s Inventory.");
/*     */           }
/*     */           
/*     */         }
/* 404 */         else if ((args[0].equalsIgnoreCase("blacklist")) && (player.hasPermission("at.blacklist"))) {
/* 405 */           if (args[1].equalsIgnoreCase("add")) {
/* 406 */             if (!this.PLUGIN.getConfig().getList("badwords").contains(args[2])) {
/* 407 */               player.sendMessage(this.prefix + "Added " + args[2] + " to the blacklist!");
/*     */               
/* 409 */               List<String> black = this.PLUGIN.getConfig().getList("badwords");
/* 410 */               black.add(args[2]);
/*     */               
/* 412 */               this.PLUGIN.saveConfig();
/* 413 */               this.PLUGIN.reloadConfig();
/*     */             } else {
/* 415 */               player.sendMessage(this.error + "That word is already on the blacklist");
/*     */             }
/*     */           }
/*     */           
/* 419 */           if (args[1].equalsIgnoreCase("remove")) {
/* 420 */             player.sendMessage(this.prefix + "Removed " + args[2] + " from the blacklist!");
/*     */             
/* 422 */             List<String> black = this.PLUGIN.getConfig().getList("badwords");
/* 423 */             black.remove(args[2]);
/*     */             
/* 425 */             this.PLUGIN.saveConfig();
/* 426 */             this.PLUGIN.reloadConfig();
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 431 */         else if ((args[0].equalsIgnoreCase("blacklisted")) && (player.hasPermission("at.blacklisted")))
/*     */         {
/* 433 */           List<String> black = this.PLUGIN.getConfig().getList("badwords");
/* 434 */           player.sendMessage(this.prefix + "Dont Say: " + black);
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 439 */         else if ((args[0].equalsIgnoreCase("contributors")) && (player.hasPermission("at.contributors"))) {
/* 440 */           player.sendMessage(this.prefix + "Thanks To All Of The Amazing Contributors:\n" + ChatColor.AQUA + 
/* 441 */             "Mr. Diamond: Helped With The GUI Idea, Permission ranks, and contributor list\n" + 
/* 442 */             "bwfcwalshy: Helped With Debugging\n");
/*     */ 
/*     */ 
/*     */         }
/* 446 */         else if ((args[0].equalsIgnoreCase("gui")) && (player.hasPermission("at.gui"))) {
/* 447 */           main.createDisplay(Material.DIAMOND_AXE, this.PLUGIN.cmdGUI, 1, 
/* 448 */             ChatColor.RED + ChatColor.BOLD + "The All Mighty Ban Hammer!", "Ban a Player!");
/* 449 */           main.createDisplay(Material.IRON_AXE, this.PLUGIN.cmdGUI, 2, 
/* 450 */             ChatColor.RED + ChatColor.BOLD + "The Kicker 9000", "Kick a Player!");
/* 451 */           main.createDisplay(Material.EYE_OF_ENDER, this.PLUGIN.cmdGUI, 3, 
/* 452 */             ChatColor.RED + ChatColor.BOLD + "Spectationeer", "Spectate a player!");
/* 453 */           main.createDisplay(Material.PACKED_ICE, this.PLUGIN.cmdGUI, 5, 
/* 454 */             ChatColor.RED + ChatColor.BOLD + "The Freezer", "Freeze a player!");
/* 455 */           main.createDisplay(Material.BEDROCK, this.PLUGIN.cmdGUI, 6, 
/* 456 */             ChatColor.RED + ChatColor.BOLD + "Gamiest Mode Changer", "Change yer Gamemode");
/* 457 */           main.createDisplay(Material.END_CRYSTAL, this.PLUGIN.cmdGUI, 7, 
/* 458 */             ChatColor.RED + ChatColor.BOLD + "Researcher", "Research a player");
/*     */           
/* 460 */           main.createDisplay(Material.BEDROCK, this.PLUGIN.gmGUI, 2, "Creative", "Be The Gawd");
/* 461 */           main.createDisplay(Material.REDSTONE_BLOCK, this.PLUGIN.gmGUI, 3, "Survival", "Survive.");
/* 462 */           main.createDisplay(Material.BARRIER, this.PLUGIN.gmGUI, 5, "Spectator", "This may be even more gawd..");
/* 463 */           main.createDisplay(Material.DIAMOND_SWORD, this.PLUGIN.gmGUI, 6, "Adventure", "Whats even the point?");
/*     */           
/* 465 */           player.openInventory(this.PLUGIN.cmdGUI);
/*     */ 
/*     */ 
/*     */ 
/*     */         }
/* 470 */         else if ((args[0].equalsIgnoreCase("voteban")) && (player.hasPermission("at.voteban"))) {
/* 471 */           Vote vb = this.PLUGIN.voteBans;
/*     */           
/* 473 */           if (args.length >= 2)
/*     */           {
/* 475 */             if (args[1].equalsIgnoreCase("yes")) {
/* 476 */               if (vb.hasVoteStarted()) {
/* 477 */                 if (vb.getVoteName().equalsIgnoreCase(player.getName())) {
/* 478 */                   player.sendMessage(ChatColor.RED + "You Cannot Vote On Your Own Vote");
/* 479 */                   return true;
/*     */                 }
/* 481 */                 if (!vb.hasPlayerVoted(player.getUniqueId().toString())) {
/* 482 */                   vb.addVoteYes(player.getUniqueId().toString());
/* 483 */                   player.sendMessage(this.prefix + "You Voted Yes to ban the player! Current Ratio (Y/N): " + 
/* 484 */                     vb.getVotesYes() + "/" + vb.getVotesNo());
/*     */                 } else {
/* 486 */                   player.sendMessage(ChatColor.RED + "[AdminTools] You Have Already Voted!");
/*     */                 }
/*     */               }
/* 489 */             } else if (args[1].equalsIgnoreCase("no")) {
/* 490 */               if (vb.getVoteName().equalsIgnoreCase(player.getName())) {
/* 491 */                 player.sendMessage(ChatColor.RED + "You Cannot Vote On Your Own Vote");
/* 492 */                 return true;
/*     */               }
/* 494 */               if (vb.hasVoteStarted()) {
/* 495 */                 if (!vb.hasPlayerVoted(player.getUniqueId().toString())) {
/* 496 */                   vb.addVoteNo(player.getUniqueId().toString());
/* 497 */                   player.sendMessage(this.prefix + "You Voted No to ban the player! Current Ratio (Y/N): " + 
/* 498 */                     vb.getVotesYes() + "/" + vb.getVotesNo());
/*     */                 } else {
/* 500 */                   player.sendMessage(ChatColor.RED + "[AdminTools] You Have Already Voted!");
/*     */                 }
/*     */               }
/*     */             }
/* 504 */             else if (!vb.hasVoteStarted()) {
/* 505 */               Player target = Bukkit.getPlayer(args[1]);
/*     */               
/* 507 */               if (target == null) {
/* 508 */                 player.sendMessage("Player not online");
/* 509 */                 return true;
/*     */               }
/*     */               
/* 512 */               String mess = "";
/*     */               
/* 514 */               if (args.length >= 3) {
/* 515 */                 for (int i = 2; i < args.length; i++) {
/* 516 */                   String arg = args[i];
/* 517 */                   mess = mess.concat(arg).concat(" ");
/*     */                 }
/*     */               }
/*     */               
/* 521 */               if (args.length > 1) {
/* 522 */                 Bukkit.broadcastMessage(this.prefix + "Started a vote ban for " + ChatColor.RED + 
/* 523 */                   target.getName() + ChatColor.AQUA + " for the reason: " + ChatColor.RED + mess + 
/* 524 */                   " do /at votekick <yes/no>!");
/*     */                 
/* 526 */                 vb.setVoteName(target.getName());
/* 527 */                 vb.setVoteReason(mess);
/* 528 */                 vb.startVote();
/*     */               } else {
/* 530 */                 player.sendMessage(this.error + "Please do /at voteban <player> <reason>");
/*     */               }
/*     */             } else {
/* 533 */               player.sendMessage(ChatColor.RED + "[AdminTools] A Vote Is Already Started!");
/*     */ 
/*     */             }
/*     */             
/*     */           }
/*     */           
/*     */ 
/*     */         }
/* 541 */         else if ((args[0].equalsIgnoreCase("votekick")) && (player.hasPermission("at.votekick"))) {
/* 542 */           Vote vk = this.PLUGIN.voteKick;
/*     */           
/* 544 */           if (args.length >= 2)
/*     */           {
/* 546 */             if (args[1].equalsIgnoreCase("yes")) {
/* 547 */               if (vk.hasVoteStarted()) {
/* 548 */                 if (vk.getVoteName().equalsIgnoreCase(player.getName())) {
/* 549 */                   player.sendMessage(ChatColor.RED + "You Cannot Vote On Your Own Vote");
/* 550 */                   return true;
/*     */                 }
/* 552 */                 if (!vk.hasPlayerVoted(player.getUniqueId().toString())) {
/* 553 */                   vk.addVoteYes(player.getUniqueId().toString());
/* 554 */                   player.sendMessage(this.prefix + "You Voted Yes to kick the player! Current Ratio (Y/N): " + 
/* 555 */                     vk.getVotesYes() + "/" + vk.getVotesNo());
/*     */                 } else {
/* 557 */                   player.sendMessage(ChatColor.RED + "[AdminTools] You Have Already Voted!");
/*     */                 }
/*     */               }
/* 560 */             } else if (args[1].equalsIgnoreCase("no")) {
/* 561 */               if (vk.getVoteName().equalsIgnoreCase(player.getName())) {
/* 562 */                 player.sendMessage(ChatColor.RED + "You Cannot Vote On Your Own Vote");
/* 563 */                 return true;
/*     */               }
/* 565 */               if (vk.hasVoteStarted()) {
/* 566 */                 if (!vk.hasPlayerVoted(player.getUniqueId().toString())) {
/* 567 */                   vk.addVoteNo(player.getUniqueId().toString());
/* 568 */                   player.sendMessage(this.prefix + "You Voted No to kick the player! Current Ratio (Y/N): " + 
/* 569 */                     vk.getVotesYes() + "/" + vk.getVotesNo());
/*     */                 } else {
/* 571 */                   player.sendMessage(ChatColor.RED + "[AdminTools] You Have Already Voted!");
/*     */                 }
/*     */               }
/*     */             }
/* 575 */             else if (!vk.hasVoteStarted()) {
/* 576 */               Player target = Bukkit.getPlayer(args[1]);
/*     */               
/* 578 */               if (target == null) {
/* 579 */                 player.sendMessage("Player not online");
/* 580 */                 return true;
/*     */               }
/*     */               
/* 583 */               String mess = "";
/*     */               
/* 585 */               if (args.length >= 3) {
/* 586 */                 for (int i = 2; i < args.length; i++) {
/* 587 */                   String arg = args[i];
/* 588 */                   mess = mess.concat(arg).concat(" ");
/*     */                 }
/*     */               }
/*     */               
/* 592 */               if (args.length > 1) {
/* 593 */                 Bukkit.broadcastMessage(this.prefix + "Started a vote kick for " + ChatColor.RED + 
/* 594 */                   target.getName() + ChatColor.AQUA + " for the reason: " + ChatColor.RED + mess + 
/* 595 */                   " do /at votekick <yes/no>!");
/*     */                 
/* 597 */                 vk.setVoteName(target.getName());
/* 598 */                 vk.setVoteReason(mess);
/* 599 */                 vk.startVote();
/*     */               } else {
/* 601 */                 player.sendMessage(this.error + "Please do /at votekick <player> <reason>");
/*     */               }
/*     */             } else {
/* 604 */               player.sendMessage(ChatColor.RED + "[AdminTools] A Vote Is Already Started!");
/*     */             }
/*     */           }
/*     */         }
/*     */       }
/*     */       
/*     */ 
/*     */ 
/* 612 */       if ((args[0].equalsIgnoreCase("mute")) && (player.hasPermission("at.mute"))) {
/* 613 */         Player target = Bukkit.getPlayer(args[1]);
/*     */         
/* 615 */         String mess = "";
/*     */         
/* 617 */         if (args.length >= 3) {
/* 618 */           for (int i = 2; i < args.length; i++) {
/* 619 */             String arg = args[i];
/* 620 */             mess = mess.concat(arg).concat(" ");
/*     */           }
/*     */         }
/*     */         
/*     */ 
/* 625 */         if (args.length < 2) {
/* 626 */           player.sendMessage(ChatColor.RED + "[AdminTools] Please specify a message!");
/*     */         }
/* 628 */         else if (!this.PLUGIN.muted.contains(target.getName())) {
/* 629 */           this.PLUGIN.muted.add(target.getName());
/* 630 */           player.sendMessage(this.prefix + "Muted " + target.getName() + "!");
/* 631 */           target.sendMessage(this.prefix + "You have been muted by: " + ChatColor.RED + player.getName() + ChatColor.AQUA + ", for the reason: " + ChatColor.RED + mess);
/*     */         } else {
/* 633 */           player.sendMessage(this.prefix + "You unmuted " + target.getName());
/* 634 */           this.PLUGIN.muted.remove(target.getName());
/*     */         }
/*     */         
/*     */       }
/*     */       else
/*     */       {
/* 640 */         player.sendMessage(this.error + "Not Enough Permissions");
/*     */       }
/*     */     }
/*     */     
/* 644 */     if ((cmd.getName().equalsIgnoreCase("report")) && (player.hasPermission("at.report"))) {
/* 645 */       String mess = "";
/*     */       
/* 647 */       for (int i = 1; i < args.length; i++) {
/* 648 */         String arg = args[i] + " ";
/* 649 */         mess = mess + arg;
/*     */       }
/*     */       
/* 652 */       Player target = Bukkit.getServer().getPlayer(args[0]);
/*     */       
/* 654 */       if (args.length == 1) {
/* 655 */         player.sendMessage(this.error + "Do /report <player> <reason>!");
/*     */       }
/* 657 */       else if (args.length == 0) {
/* 658 */         player.sendMessage(this.error + "Please Specify A Player!");
/*     */       } else {
/* 660 */         player.sendMessage(this.prefix + "Successfully Reported " + ChatColor.RED + target.getName() + 
/* 661 */           ChatColor.AQUA + " for the reason: " + ChatColor.RED + mess);
/* 662 */         this.PLUGIN.getConfig().addDefault("Reported." + target.getName() + ".Report", mess);
/* 663 */         this.PLUGIN.getConfig().addDefault("Reported." + target.getName() + ".Reporter", player.getName());
/* 664 */         this.PLUGIN.saveConfig();
/*     */         
/* 666 */         Bukkit.broadcast(this.prefix + target.getName() + " was reported by " + player.getName() + 
/* 667 */           " for the reason: " + mess, "at.recieve");
/*     */       }
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 673 */     return true;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kento\Desktop\server\plugins\AdminToolsRevamped.jar!\com\kentonvizdos\ATR\Atexecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */