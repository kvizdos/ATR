/*    */ package com.kentonvizdos.ATR;
/*    */ 
/*    */ import net.md_5.bungee.api.ChatColor;
/*    */ import org.bukkit.Bukkit;
/*    */ import org.bukkit.command.Command;
/*    */ import org.bukkit.command.CommandExecutor;
/*    */ import org.bukkit.command.CommandSender;
/*    */ import org.bukkit.entity.Player;
/*    */ 
/*    */ public class Emergencyexecutor implements CommandExecutor
/*    */ {
/*    */   private final main PLUGIN;
/*    */   
/*    */   public Emergencyexecutor(main plugin)
/*    */   {
/* 16 */     this.PLUGIN = plugin;
/*    */   }
/*    */   
/*    */ 
/* 20 */   String error = ChatColor.DARK_RED + "[AdminTools] Error in syntax! ";
/* 21 */   String prefix = ChatColor.DARK_AQUA + "[" + ChatColor.AQUA + "AdminTools" + ChatColor.DARK_AQUA + "] " + ChatColor.AQUA;
/*    */   
/*    */   public boolean onCommand(CommandSender sender, Command cmd, String commandLabel, String[] args)
/*    */   {
/* 25 */     Player player = (Player)sender;
/*    */     
/* 27 */     if ((cmd.getName().equalsIgnoreCase("911")) && (player.hasPermission("at.emergency"))) {
/* 28 */       String mess = "";
/*    */       
/* 30 */       for (int i = 1; i < args.length; i++) {
/* 31 */         String arg = args[i] + " ";
/* 32 */         mess = mess + arg;
/*    */       }
/*    */       
/* 35 */       if (args.length == 1) {
/* 36 */         player.sendMessage(this.error + "Do /911 <hidden/visible> <reason>!");
/*    */       } else {
/* 38 */         if (args[0].equalsIgnoreCase("hidden")) {
/* 39 */           player.sendMessage(this.prefix + "A Invisible Admin Is On His/Her Way!");
/* 40 */           Bukkit.broadcast(this.PLUGIN.prefix + player.getName() + " has requested a invisible admin for the reason: " + ChatColor.GREEN + mess, "at.recieve");
/*    */         }
/*    */         
/* 43 */         if (args[0].equalsIgnoreCase("visible")) {
/* 44 */           player.sendMessage(this.prefix + "A Visible Admin Is On His/Her Way!");
/* 45 */           Bukkit.broadcast(this.prefix + player.getName() + " has requested a visible admin for the reason: " + ChatColor.GREEN + mess, "at.recieve");
/*    */         }
/*    */       }
/*    */     }
/*    */     
/* 50 */     return false;
/*    */   }
/*    */ }


/* Location:              C:\Users\Kento\Desktop\server\plugins\AdminToolsRevamped.jar!\com\kentonvizdos\ATR\Emergencyexecutor.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */