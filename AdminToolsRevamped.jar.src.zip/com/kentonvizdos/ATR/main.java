/*     */ package com.kentonvizdos.ATR;
/*     */ 
/*     */ import java.io.PrintStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.HashMap;
/*     */ import net.md_5.bungee.api.ChatColor;
/*     */ import org.bukkit.Bukkit;
/*     */ import org.bukkit.GameMode;
/*     */ import org.bukkit.Material;
/*     */ import org.bukkit.OfflinePlayer;
/*     */ import org.bukkit.Server;
/*     */ import org.bukkit.command.PluginCommand;
/*     */ import org.bukkit.configuration.file.FileConfiguration;
/*     */ import org.bukkit.entity.Player;
/*     */ import org.bukkit.event.EventHandler;
/*     */ import org.bukkit.event.Listener;
/*     */ import org.bukkit.event.block.SignChangeEvent;
/*     */ import org.bukkit.event.inventory.InventoryClickEvent;
/*     */ import org.bukkit.event.player.AsyncPlayerChatEvent;
/*     */ import org.bukkit.event.player.PlayerCommandPreprocessEvent;
/*     */ import org.bukkit.event.player.PlayerJoinEvent;
/*     */ import org.bukkit.event.player.PlayerMoveEvent;
/*     */ import org.bukkit.event.player.PlayerQuitEvent;
/*     */ import org.bukkit.inventory.Inventory;
/*     */ import org.bukkit.inventory.ItemStack;
/*     */ import org.bukkit.inventory.meta.ItemMeta;
/*     */ import org.bukkit.inventory.meta.SkullMeta;
/*     */ import org.bukkit.plugin.PluginManager;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public final class main
/*     */   extends JavaPlugin implements Listener
/*     */ {
/*     */   Vote voteBans;
/*     */   Vote voteKick;
/*  38 */   ArrayList<String> banned = new ArrayList();
/*  39 */   ArrayList<String> frozen = new ArrayList();
/*  40 */   ArrayList<String> warns = new ArrayList();
/*  41 */   ArrayList<String> muted = new ArrayList();
/*     */   
/*  43 */   HashMap<String, Integer> beingVoteBanned = new HashMap();
/*  44 */   ArrayList<String> guiBanReason = new ArrayList();
/*  45 */   ArrayList<String> guiBanner = new ArrayList();
/*  46 */   ArrayList<String> guiBanned = new ArrayList();
/*     */   
/*  48 */   public boolean spectating = false;
/*     */   
/*     */ 
/*     */   public void loadConfiguration() {}
/*     */   
/*     */   public String stripColorFromConfig(String config)
/*     */   {
/*  55 */     return 
/*     */     
/*     */ 
/*  58 */       config.replaceAll("RED", ChatColor.RED).replaceAll("BLUE", ChatColor.BLUE).replaceAll("GREEN", ChatColor.GREEN).replaceAll("GOLD", ChatColor.GOLD).replaceAll("GRAY", ChatColor.GRAY).replaceAll("DG", ChatColor.DARK_GRAY).replaceAll("AQUA", ChatColor.AQUA);
/*     */   }
/*     */   
/*     */ 
/*     */   public void onEnable()
/*     */   {
/*  64 */     loadConfiguration();
/*  65 */     System.out.print("[TestPlugin] TestPlugin Enabled!");
/*     */     
/*  67 */     Bukkit.getServer().getPluginManager().registerEvents(this, this);
/*     */     
/*  69 */     saveDefaultConfig();
/*  70 */     getCommand("at").setExecutor(new Atexecutor(this));
/*  71 */     getCommand("911").setExecutor(new Emergencyexecutor(this));
/*  72 */     getCommand("report").setExecutor(new Reportexecutor(this));
/*     */     
/*  74 */     this.voteBans = new Vote(this, "", getConfig().getInt("Settings.AutoBan.Length"))
/*     */     {
/*     */       public void endVote() {
/*  77 */         Player b = Bukkit.getPlayer(getVoteName());
/*  78 */         if (b != null) {
/*  79 */           b.kickPlayer(ChatColor.RED + "You Have Been Banned! \n Reason: " + ChatColor.DARK_RED + 
/*  80 */             getVoteReason() + ChatColor.RED + " \n Banned By: " + ChatColor.DARK_RED + 
/*  81 */             "The Masses (Vote Ban)" + ChatColor.RED + "\n Appeal Here: \n" + ChatColor.DARK_RED + 
/*  82 */             main.this.getConfig().getString("Settings.Ban.AppealLink"));
/*     */         }
/*  84 */         OfflinePlayer banned = Bukkit.getOfflinePlayer(getVoteName());
/*     */         
/*  86 */         if (getVotesYes() > getVotesNo()) {
/*  87 */           main.this.getConfig().set("Players.Banned." + banned.getUniqueId() + ".Reason", getVoteReason());
/*  88 */           main.this.getConfig().set("Players.Banned." + banned.getUniqueId() + ".Banner", 
/*  89 */             "Banned By The Masses (Vote Ban)");
/*  90 */           main.this.saveConfig();
/*  91 */           Bukkit.broadcastMessage(
/*  92 */             main.this.prefix + "The player was vote banned " + getVoteName() + ". The Vote Ratio being (Y/N): " + 
/*  93 */             getVotesYes() + ChatColor.DARK_AQUA + "/" + ChatColor.AQUA + getVotesNo());
/*  94 */         } else if (getVotesYes() == getVotesNo()) {
/*  95 */           Bukkit.broadcastMessage(main.this.prefix + "The Vote Was A Tie, No One Will Be Banned... Today..");
/*  96 */         } else if (getVotesYes() < getVotesNo()) {
/*  97 */           Bukkit.broadcastMessage(
/*  98 */             main.this.prefix + "More players decided to give the player another chance. No one will be banned. ");
/*     */         }
/*     */         
/*     */       }
/* 102 */     };
/* 103 */     this.voteKick = new Vote(this, "", getConfig().getInt("Settings.AutoBan.Length"))
/*     */     {
/*     */       public void endVote()
/*     */       {
/* 107 */         Player banned = Bukkit.getPlayer(getVoteName());
/*     */         
/* 109 */         if (getVotesYes() > getVotesNo()) {
/* 110 */           if (banned != null) {
/* 111 */             banned.kickPlayer(ChatColor.RED + "You Have Been Kicked! \n Reason: " + ChatColor.DARK_RED + 
/* 112 */               "The Masses (Vote Kick)" + ChatColor.RED + " \n Kicked By: " + ChatColor.DARK_RED + 
/* 113 */               "The Masses");
/*     */           }
/* 115 */           Bukkit.broadcastMessage(
/* 116 */             main.this.prefix + "The player was vote kicked " + getVoteName() + ". The Vote Ratio being (Y/N): " + 
/* 117 */             getVotesYes() + ChatColor.DARK_AQUA + "/" + ChatColor.AQUA + getVotesNo());
/*     */         }
/* 119 */         else if (getVotesYes() == getVotesNo()) {
/* 120 */           Bukkit.broadcastMessage(main.this.prefix + "The Vote Was A Tie, No One Will Be Banned... Today..");
/* 121 */         } else if (getVotesYes() < getVotesNo()) {
/* 122 */           Bukkit.broadcastMessage(
/* 123 */             main.this.prefix + "More players decided to give the player another chance. No one will be banned. ");
/*     */         }
/*     */         
/*     */       }
/*     */       
/* 128 */     };
/* 129 */     BukkitScheduler scheduler = getServer().getScheduler();
/*     */     
/* 131 */     if (getConfig().getBoolean("Settings.Autobroadcaster.Enabled"))
/*     */     {
/* 133 */       scheduler.scheduleSyncRepeatingTask(this, new Runnable()
/*     */       {
/*     */         public void run() {
/* 136 */           Bukkit.broadcastMessage(
/* 137 */             main.this.stripColorFromConfig(main.this.getConfig().getString("Settings.Autobroadcaster.Msg")));
/*     */         }
/* 139 */       }, 0L, getConfig().getLong("Settings.Autobroadcaster.Delay"));
/*     */     }
/*     */     else {
/* 142 */       Bukkit.broadcast(this.prefix + "Autobroadcaster Not Enabled!", "at.recieve");
/*     */     }
/*     */   }
/*     */   
/* 146 */   HashMap<String, Boolean> BannedPlayers = new HashMap();
/*     */   
/*     */   public void onDisable()
/*     */   {
/* 150 */     System.out.println(ChatColor.BLUE + "UnLoaded!");
/*     */   }
/*     */   
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/* 162 */   Inventory cmdGUI = Bukkit.createInventory(null, 9, ChatColor.AQUA + "AdminTools GUI beta 1.0");
/*     */   
/* 164 */   int ps = Bukkit.getOnlinePlayers().size();
/* 165 */   Inventory banPlayers = Bukkit.createInventory(null, 54, ChatColor.AQUA + "AdminTools >>" + ChatColor.RED + " Ban");
/* 166 */   Inventory kickGUI = Bukkit.createInventory(null, 54, ChatColor.AQUA + "AdminTools >>" + ChatColor.RED + " Kick");
/*     */   
/* 168 */   Inventory specGUI = Bukkit.createInventory(null, 54, ChatColor.AQUA + "AdminTools >>" + ChatColor.DARK_BLUE + " Spectate");
/*     */   
/* 170 */   Inventory freezeGUI = Bukkit.createInventory(null, 54, ChatColor.AQUA + "AdminTools >>" + ChatColor.BLUE + " Freezer");
/* 171 */   Inventory gmGUI = Bukkit.createInventory(null, 9, ChatColor.AQUA + "AdminTools >>" + ChatColor.GREEN + " GM'r");
/*     */   
/* 173 */   Inventory researchGUI = Bukkit.createInventory(null, 54, ChatColor.AQUA + "AdminTools >>" + ChatColor.DARK_PURPLE + " Research");
/*     */   
/*     */   public static void createDisplay(Material material, Inventory inv, int Slot, String name, String lore)
/*     */   {
/* 177 */     ItemStack item = new ItemStack(material);
/* 178 */     ItemMeta meta = item.getItemMeta();
/*     */     
/* 180 */     meta.setDisplayName(name);
/* 181 */     ArrayList<String> Lore = new ArrayList();
/* 182 */     Lore.add(lore);
/* 183 */     meta.setLore(Lore);
/* 184 */     item.setItemMeta(meta);
/*     */     
/* 186 */     inv.setItem(Slot, item);
/*     */   }
/*     */   
/*     */ 
/*     */ 
/* 191 */   String error = ChatColor.DARK_RED + "[AdminTools] Error in syntax! ";
/* 192 */   String prefix = ChatColor.DARK_AQUA + "[" + ChatColor.AQUA + "AdminTools" + ChatColor.DARK_AQUA + "] " + 
/* 193 */     ChatColor.AQUA;
/*     */   
/*     */   @EventHandler
/*     */   public void playerChatEvent(AsyncPlayerChatEvent e)
/*     */   {
/* 198 */     Player p = e.getPlayer();
/* 199 */     for (String badword : getConfig().getStringList("badwords")) {
/* 200 */       if (e.getMessage().equalsIgnoreCase(badword)) {
/* 201 */         e.setCancelled(true);
/* 202 */         p.sendMessage(this.error + ChatColor.RED + 
/* 203 */           "You Used A Bad Word, So The Message Got Deleted! A staff member has been informed!");
/* 204 */         Bukkit.broadcast(this.prefix + ChatColor.RED + "Player " + ChatColor.GREEN + p.getName() + ChatColor.RED + 
/* 205 */           " said: " + e.getMessage(), "At.recieve");
/*     */       }
/*     */     }
/*     */     
/* 209 */     if ((this.voteBans.getVoteName().equalsIgnoreCase(p.getName())) && (this.voteBans.hasVoteStarted())) {
/* 210 */       p.sendMessage(this.prefix + "You are being Vote Banned so you can no longer chat until the vote is over!");
/* 211 */       e.setCancelled(true);
/*     */     }
/*     */     
/* 214 */     if (this.guiBanner.contains(p.getName()))
/*     */     {
/* 216 */       e.setCancelled(true);
/* 217 */       this.guiBanReason.add(e.getMessage());
/* 218 */       p.sendMessage(this.prefix + "Reason for ban: " + this.guiBanReason.toString());
/* 219 */       this.guiBanner.remove(p.getName());
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 224 */     if (this.muted.contains(p.getName())) {
/* 225 */       e.setCancelled(true);
/* 226 */       p.sendMessage(ChatColor.RED + "[AdminTools] You Are Muted And Can Not Talk!");
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerCommand(PlayerCommandPreprocessEvent e)
/*     */   {
/* 233 */     Player p = e.getPlayer();
/*     */     
/* 235 */     if (this.muted.contains(p.getName())) {
/* 236 */       e.setCancelled(true);
/*     */       
/* 238 */       p.sendMessage(ChatColor.RED + "[AdminTools] You are muted and con not run commands!");
/*     */     }
/*     */     
/* 241 */     if ((this.voteBans.getVoteName().equalsIgnoreCase(p.getName())) && (this.voteBans.hasVoteStarted())) {
/* 242 */       p.sendMessage(this.prefix + "You are being Vote Banned so you can no longer chat until the vote is over!");
/* 243 */       e.setCancelled(true);
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/* 248 */   public void onSignChange(SignChangeEvent e) { if (e.getLine(0).equalsIgnoreCase(getConfig().getStringList("badwords"))) e.setLine(0, "DON SAY DAT");
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerJoin(PlayerJoinEvent e)
/*     */   {
/* 254 */     Player p = e.getPlayer();
/* 255 */     if (p.getName().equalsIgnoreCase("DiamondMCPro")) {
/* 256 */       e.setJoinMessage("");
/*     */     } else {
/* 258 */       e.setJoinMessage(getConfig().getString("Settings.Join.Msg").replaceAll("PLAYER", p.getName())
/* 259 */         .replaceAll("RED", ChatColor.RED).replaceAll("BLUE", ChatColor.BLUE)
/* 260 */         .replaceAll("GREEN", ChatColor.GREEN).replaceAll("GOLD", ChatColor.GOLD)
/* 261 */         .replaceAll("GRAY", ChatColor.GRAY).replaceAll("DG", ChatColor.DARK_GRAY)
/* 262 */         .replaceAll("AQUA", ChatColor.AQUA));
/* 263 */       if (getConfig().isSet("Players.Banned." + p.getUniqueId())) {
/* 264 */         p.kickPlayer(ChatColor.RED + "You Have Been Banned! \n Reason: " + ChatColor.DARK_RED + 
/* 265 */           getConfig().getString(new StringBuilder("Players.Banned.").append(p.getUniqueId()).append(".Reason").toString()) + ChatColor.RED + 
/* 266 */           "\n Banned By: " + ChatColor.DARK_RED + 
/* 267 */           getConfig().getString(new StringBuilder("Players.Banned.").append(p.getUniqueId()).append(".Banner").toString()) + ChatColor.RED + 
/* 268 */           "\n Appeal Here: \n" + ChatColor.DARK_RED + getConfig().getString("Settings.Ban.AppealLink"));
/* 269 */         e.setJoinMessage("");
/*     */       }
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerLeave(PlayerQuitEvent e) {
/* 276 */     Player p = e.getPlayer();
/* 277 */     e.setQuitMessage(getConfig().getString("Settings.Leave.Msg").replaceAll("PLAYER", p.getName())
/* 278 */       .replaceAll("RED", ChatColor.RED).replaceAll("BLUE", ChatColor.BLUE)
/* 279 */       .replaceAll("GREEN", ChatColor.GREEN).replaceAll("GOLD", ChatColor.GOLD)
/* 280 */       .replaceAll("GRAY", ChatColor.GRAY).replaceAll("DG", ChatColor.DARK_GRAY)
/* 281 */       .replaceAll("AQUA", ChatColor.AQUA));
/*     */     
/* 283 */     if (getConfig().isSet("Players.Banned." + p.getUniqueId())) {
/* 284 */       e.setQuitMessage("");
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onPlayerMove(PlayerMoveEvent e) {
/* 290 */     Player p = e.getPlayer();
/* 291 */     if (this.frozen.contains(p.getName())) {
/* 292 */       e.setTo(e.getFrom());
/*     */     }
/*     */   }
/*     */   
/*     */   @EventHandler
/*     */   public void onInventoryClick(InventoryClickEvent e)
/*     */   {
/* 299 */     Player p = (Player)e.getWhoClicked();
/* 300 */     ItemStack clicked = e.getCurrentItem();
/* 301 */     Inventory inventory = e.getInventory();
/*     */     
/* 303 */     int slot = 0;
/*     */     
/* 305 */     if (inventory.getName().equals(this.cmdGUI.getName())) {
/* 306 */       switch (clicked.getType()) {
/*     */       case MELON: 
/* 308 */         e.setCancelled(true);
/* 309 */         p.closeInventory();
/* 310 */         p.openInventory(this.banPlayers);
/* 311 */         for (Player ban : Bukkit.getOnlinePlayers()) {
/* 312 */           ItemStack skull = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
/* 313 */           SkullMeta smeta = (SkullMeta)skull.getItemMeta();
/* 314 */           smeta.setOwner(ban.getName());
/* 315 */           smeta.setDisplayName(ban.getName());
/* 316 */           skull.setItemMeta(smeta);
/* 317 */           this.banPlayers.setItem(slot, skull);
/* 318 */           slot++;
/*     */         }
/* 320 */         break;
/*     */       case LADDER: 
/* 322 */         e.setCancelled(true);
/* 323 */         p.closeInventory();
/* 324 */         p.openInventory(this.kickGUI);
/* 325 */         for (Player kick : Bukkit.getOnlinePlayers()) {
/* 326 */           ItemStack skull = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
/* 327 */           SkullMeta smeta = (SkullMeta)skull.getItemMeta();
/* 328 */           smeta.setOwner(kick.getName());
/* 329 */           smeta.setDisplayName(kick.getName());
/* 330 */           skull.setItemMeta(smeta);
/* 331 */           this.kickGUI.setItem(slot, skull);
/* 332 */           slot++;
/*     */         }
/* 334 */         break;
/*     */       case SKULL: 
/* 336 */         e.setCancelled(true);
/* 337 */         p.closeInventory();
/* 338 */         p.openInventory(this.specGUI);
/* 339 */         for (Player spectated : Bukkit.getOnlinePlayers()) {
/* 340 */           ItemStack skull = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
/* 341 */           SkullMeta smeta = (SkullMeta)skull.getItemMeta();
/* 342 */           smeta.setOwner(spectated.getName());
/* 343 */           smeta.setDisplayName(spectated.getName());
/* 344 */           skull.setItemMeta(smeta);
/* 345 */           this.specGUI.setItem(slot, skull);
/* 346 */           slot++;
/*     */         }
/* 348 */         break;
/*     */       case GOLD_LEGGINGS: 
/* 350 */         e.setCancelled(true);
/* 351 */         p.closeInventory();
/* 352 */         p.openInventory(this.freezeGUI);
/* 353 */         for (Player freezed : Bukkit.getOnlinePlayers()) {
/* 354 */           ItemStack skull = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
/* 355 */           SkullMeta smeta = (SkullMeta)skull.getItemMeta();
/* 356 */           smeta.setOwner(freezed.getName());
/* 357 */           smeta.setDisplayName(freezed.getName());
/* 358 */           skull.setItemMeta(smeta);
/* 359 */           this.freezeGUI.setItem(slot, skull);
/* 360 */           slot++;
/*     */         }
/* 362 */         break;
/*     */       case ANVIL: 
/* 364 */         e.setCancelled(true);
/* 365 */         p.closeInventory();
/* 366 */         p.openInventory(this.gmGUI);
/* 367 */         break;
/*     */       case SULPHUR: 
/* 369 */         e.setCancelled(true);
/* 370 */         p.closeInventory();
/* 371 */         p.openInventory(this.researchGUI);
/* 372 */         for (Player researchee : Bukkit.getOnlinePlayers()) {
/* 373 */           ItemStack skull = new ItemStack(Material.SKULL_ITEM, 1, (short)3);
/* 374 */           SkullMeta smeta = (SkullMeta)skull.getItemMeta();
/* 375 */           smeta.setOwner(researchee.getName());
/* 376 */           smeta.setDisplayName(researchee.getName());
/* 377 */           skull.setItemMeta(smeta);
/* 378 */           this.researchGUI.setItem(slot, skull);
/* 379 */           slot++;
/*     */         }
/*     */       }
/*     */       
/*     */     }
/*     */     
/*     */ 
/*     */ 
/* 387 */     if (inventory.getName().equals(this.banPlayers.getName()))
/*     */     {
/* 389 */       String playername = e.getCurrentItem().getItemMeta().getDisplayName();
/* 390 */       Player bannd = Bukkit.getPlayer(playername);
/*     */       
/* 392 */       if (clicked.getType() == Material.SKULL_ITEM) {
/* 393 */         e.setCancelled(true);
/* 394 */         p.closeInventory();
/*     */         
/* 396 */         p.sendMessage(this.prefix + "Banned " + bannd.getName() + "!");
/* 397 */         bannd.kickPlayer(ChatColor.RED + "You Have Been Banned! \n Reason: " + ChatColor.DARK_RED + 
/* 398 */           "The Ban Hammer Has Spoken!" + ChatColor.RED + " \n Banned By: " + ChatColor.DARK_RED + 
/* 399 */           p.getName() + ChatColor.RED + "\n Appeal Here: \n" + ChatColor.DARK_RED + 
/* 400 */           getConfig().getString("Settings.Ban.AppealLink"));
/* 401 */         this.banned.add(bannd.getName());
/*     */         
/* 403 */         getConfig().set("Players.Banned." + bannd.getUniqueId() + ".Reason", "The Ban Hammer Has Spoken!");
/* 404 */         getConfig().set("Players.Banned." + bannd.getUniqueId() + ".Banner", p.getName());
/*     */         
/* 406 */         saveConfig();
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 411 */     if (inventory.getName().equals(this.kickGUI.getName()))
/*     */     {
/* 413 */       String playername = e.getCurrentItem().getItemMeta().getDisplayName();
/* 414 */       Player bannd = Bukkit.getPlayer(playername);
/*     */       
/* 416 */       if (clicked.getType() == Material.SKULL_ITEM) {
/* 417 */         e.setCancelled(true);
/* 418 */         p.closeInventory();
/* 419 */         p.sendMessage(this.prefix + "Kicked " + bannd.getName() + "!");
/* 420 */         bannd.kickPlayer(ChatColor.RED + "You Have Been Kicked! \n Reason: " + ChatColor.DARK_RED + 
/* 421 */           "The Kicker 9000 Has Spoken!" + ChatColor.RED + " \n Kicked By: " + ChatColor.DARK_RED + 
/* 422 */           p.getName());
/*     */       }
/*     */     }
/*     */     
/*     */ 
/* 427 */     if (inventory.getName().equals(this.specGUI.getName()))
/*     */     {
/* 429 */       String playername = e.getCurrentItem().getItemMeta().getDisplayName();
/* 430 */       Player spectated = Bukkit.getPlayer(playername);
/*     */       
/* 432 */       if (clicked.getType() == Material.SKULL_ITEM) {
/* 433 */         p.closeInventory();
/* 434 */         p.setGameMode(GameMode.SPECTATOR);
/* 435 */         p.teleport(spectated);
/* 436 */         p.sendMessage(this.prefix + "Spectating " + spectated.getName());
/* 437 */         e.setCancelled(true);
/*     */       }
/*     */     }
/*     */     
/* 441 */     if (inventory.getName().equals(this.researchGUI.getName())) {
/* 442 */       String playername = e.getCurrentItem().getItemMeta().getDisplayName();
/* 443 */       Player researchee = Bukkit.getPlayer(playername);
/*     */       
/* 445 */       if (clicked.getType() == Material.SKULL_ITEM) {
/* 446 */         e.setCancelled(true);
/* 447 */         p.closeInventory();
/* 448 */         p.sendMessage(ChatColor.AQUA + "More Info About " + ChatColor.GREEN + researchee.getName());
/* 449 */         p.sendMessage(ChatColor.BLUE + "Name: " + ChatColor.GREEN + researchee.getName());
/* 450 */         p.sendMessage(ChatColor.BLUE + "UUID: " + ChatColor.GREEN + researchee.getUniqueId());
/* 451 */         p.sendMessage(ChatColor.BLUE + "IP: " + ChatColor.GREEN + researchee.getAddress());
/* 452 */         p.sendMessage(ChatColor.BLUE + "Entity ID: " + ChatColor.GREEN + researchee.getEntityId());
/* 453 */         p.sendMessage(ChatColor.BLUE + "Player Time: " + ChatColor.GREEN + researchee.getPlayerTime());
/*     */       }
/*     */     }
/*     */     
/* 457 */     if (inventory.getName().equals(this.freezeGUI.getName()))
/*     */     {
/* 459 */       String playername = e.getCurrentItem().getItemMeta().getDisplayName();
/* 460 */       Player frozened = Bukkit.getPlayer(playername);
/*     */       
/* 462 */       if (clicked.getType() == Material.SKULL_ITEM) {
/* 463 */         if (this.frozen.contains(frozened.getName())) {
/* 464 */           p.closeInventory();
/* 465 */           this.frozen.remove(frozened.getName());
/* 466 */           p.sendMessage(this.prefix + "Unfroze " + frozened.getName());
/* 467 */           e.setCancelled(true);
/*     */         } else {
/* 469 */           p.closeInventory();
/* 470 */           this.frozen.add(frozened.getName());
/* 471 */           p.sendMessage(this.prefix + "Froze " + frozened.getName());
/* 472 */           e.setCancelled(true);
/*     */         }
/*     */       }
/*     */     }
/* 476 */     if (inventory.getName().equals(this.gmGUI.getName())) {
/* 477 */       switch (clicked.getType()) {
/*     */       case ANVIL: 
/* 479 */         e.setCancelled(true);
/* 480 */         p.closeInventory();
/* 481 */         p.setGameMode(GameMode.CREATIVE);
/* 482 */         p.sendMessage(this.prefix + "Changed Gamemode To Creative!");
/* 483 */         break;
/*     */       
/*     */       case FLINT: 
/* 486 */         e.setCancelled(true);
/* 487 */         p.closeInventory();
/* 488 */         p.setGameMode(GameMode.SURVIVAL);
/* 489 */         p.sendMessage(this.prefix + "Changed Gamemode To Survival!");
/* 490 */         break;
/*     */       
/*     */       case GOLD_AXE: 
/* 493 */         e.setCancelled(true);
/* 494 */         p.closeInventory();
/* 495 */         p.setGameMode(GameMode.SPECTATOR);
/* 496 */         p.sendMessage(this.prefix + "Changed Gamemode To Spectator Mode!");
/* 497 */         break;
/*     */       
/*     */       case MAGMA: 
/* 500 */         e.setCancelled(true);
/* 501 */         p.closeInventory();
/* 502 */         p.setGameMode(GameMode.ADVENTURE);
/* 503 */         p.sendMessage(this.prefix + "Changed Gamemode To Adventure Mode!");
/*     */       }
/*     */     }
/*     */   }
/*     */ }


/* Location:              C:\Users\Kento\Desktop\server\plugins\AdminToolsRevamped.jar!\com\kentonvizdos\ATR\main.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */