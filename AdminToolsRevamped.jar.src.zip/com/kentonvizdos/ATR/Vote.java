/*     */ package com.kentonvizdos.ATR;
/*     */ 
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import org.bukkit.plugin.java.JavaPlugin;
/*     */ import org.bukkit.scheduler.BukkitScheduler;
/*     */ 
/*     */ public abstract class Vote
/*     */ {
/*     */   private String voteName;
/*     */   private JavaPlugin plugin;
/*  12 */   private List<String> playersWhoVoted = new ArrayList();
/*     */   private int voteLength;
/*     */   private int votesYes;
/*     */   private int votesNo;
/*     */   private boolean voteStarted;
/*     */   private String voteReason;
/*     */   
/*     */   public Vote(JavaPlugin plugin, String voteName, int voteLength) {
/*  20 */     this.plugin = plugin;
/*  21 */     this.voteName = voteName;
/*  22 */     this.voteLength = voteLength;
/*  23 */     this.votesNo = 0;
/*  24 */     this.votesYes = 0;
/*  25 */     this.voteStarted = false;
/*     */   }
/*     */   
/*     */   public void startVote() {
/*  29 */     this.voteStarted = true;
/*  30 */     org.bukkit.Bukkit.getScheduler().scheduleSyncDelayedTask(this.plugin, new Runnable()
/*     */     {
/*     */       public void run() {
/*  33 */         Vote.this.onVoteEnd();
/*     */       }
/*  35 */     }, this.voteLength * 20L);
/*     */   }
/*     */   
/*     */   private void onVoteEnd() {
/*  39 */     endVote();
/*  40 */     clearVotes();
/*  41 */     setVoteName("");
/*  42 */     this.voteStarted = false;
/*     */   }
/*     */   
/*     */   public abstract void endVote();
/*     */   
/*     */   public int getVoteLength() {
/*  48 */     return this.voteLength;
/*     */   }
/*     */   
/*     */   public void setVoteLength(int voteLength) {
/*  52 */     this.voteLength = voteLength;
/*     */   }
/*     */   
/*     */   public int getVotesYes() {
/*  56 */     return this.votesYes;
/*     */   }
/*     */   
/*     */   public void setVotesYes(int votesYes) {
/*  60 */     this.votesYes = votesYes;
/*     */   }
/*     */   
/*     */   public void addVoteYes() {
/*  64 */     this.votesYes += 1;
/*     */   }
/*     */   
/*     */   public void addVoteNo() {
/*  68 */     this.votesNo += 1;
/*     */   }
/*     */   
/*     */   public void addVoteYes(String playerUID) {
/*  72 */     this.votesYes += 1;
/*  73 */     this.playersWhoVoted.add(playerUID);
/*     */   }
/*     */   
/*     */   public int getVotesNo() {
/*  77 */     return this.votesNo;
/*     */   }
/*     */   
/*     */   public void setVotesNo(int votesNo) {
/*  81 */     this.votesNo = votesNo;
/*     */   }
/*     */   
/*     */   public void addVoteNo(String playerUID) {
/*  85 */     this.votesNo += 1;
/*  86 */     this.playersWhoVoted.add(playerUID);
/*     */   }
/*     */   
/*     */   public int getTotalVotes() {
/*  90 */     return this.votesYes + this.votesNo;
/*     */   }
/*     */   
/*     */   public boolean hasPlayerVoted(String playerUID) {
/*  94 */     return this.playersWhoVoted.contains(playerUID);
/*     */   }
/*     */   
/*     */   public void setVoteName(String voteName) {
/*  98 */     this.voteName = voteName;
/*     */   }
/*     */   
/*     */   public String getVoteName() {
/* 102 */     return this.voteName;
/*     */   }
/*     */   
/*     */   public void clearVotes() {
/* 106 */     this.votesYes = 0;
/* 107 */     this.votesNo = 0;
/* 108 */     this.playersWhoVoted.removeAll(this.playersWhoVoted);
/*     */   }
/*     */   
/*     */   public boolean hasVoteStarted() {
/* 112 */     return this.voteStarted;
/*     */   }
/*     */   
/*     */   public void setVoteReason(String voteReason) {
/* 116 */     this.voteReason = voteReason;
/*     */   }
/*     */   
/*     */   public String getVoteReason() {
/* 120 */     return this.voteReason;
/*     */   }
/*     */ }


/* Location:              C:\Users\Kento\Desktop\server\plugins\AdminToolsRevamped.jar!\com\kentonvizdos\ATR\Vote.class
 * Java compiler version: 8 (52.0)
 * JD-Core Version:       0.7.1
 */